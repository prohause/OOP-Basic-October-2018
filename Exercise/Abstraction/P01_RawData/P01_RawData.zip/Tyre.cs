﻿namespace P01_RawData
{
    public class Tyre
    {
        public double Pressure
        {
            get; set;
        }

        public int Age
        {
            get; set;
        }

        public Tyre(double pressure, int age)
        {
            Pressure = pressure;
            Age = age;
        }
    }
}